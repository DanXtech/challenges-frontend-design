Hi there

This is a Social Media Dashboard which gives insights on your follwers and likes from various social media handles like Linkedin, Twitter and Instagram. A huge shoutout to
Coding Master for providing inspiration and support for this project. A special mention to CodeAlpha under the internship of which I've created this project.
